package helper.model.service;

import helper.model.entity.Helper;
import java.util.ArrayList;
import java.util.List;

public class HelperService {

    private static List<Helper> helperList = new ArrayList<>();
    private static Long sequence = 0L;

    public void create(Helper helper) throws Exception {
        helper.setId(++sequence);
        helperList.add(helper);

    }

    public Helper readById(Long id) throws Exception {
        Helper helper = null;
        for (Helper aux : helperList) {
            if (aux.getId().equals(id)) {
                helper = aux;
                break;
            }
        }
        return helper;
    }

    public List<Helper> read() throws Exception {
        return helperList;
    }

    public void update(Helper helper) throws Exception {
        for (Helper aux : helperList) {
            if (aux.getId().equals(helper.getId())) {
                aux.setNome(helper.getNome());
                aux.setRazao(helper.getRazao());
                aux.setCnpj(helper.getCnpj());
                aux.setIe(helper.getIe());
                aux.setLogradouro(helper.getLogradouro());
                aux.setNumero(helper.getNumero());
                aux.setBairro(helper.getBairro());
                aux.setMunicipio(helper.getMunicipio());
                aux.setUf(helper.getUf());
                aux.setCep(helper.getCep());
                aux.setEmail(helper.getEmail());
                aux.setTelefone(helper.getTelefone());
                break;
            }
        }
    }

    public void delete(Long id) throws Exception {
        for (Helper aux : helperList) {
            if (aux.getId().equals(id)) {
                helperList.remove(aux);
                break;
            }
        }

    }
}
