package helper.controller;

import helper.model.entity.Helper;
import helper.model.service.HelperService;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelperController {

    @RequestMapping(value = "/helper/form", method = RequestMethod.GET)
    public ModelAndView getForm() {
        ModelAndView mv = new ModelAndView("form");
        return mv;
    }

    @RequestMapping(value = "/helper/form", method = RequestMethod.POST)
    public ModelAndView create(Helper helper) {

        ModelAndView mv = null;
        try {
            HelperService service = new HelperService();
            service.create(helper);
            mv = new ModelAndView("redirect:/helper");
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }

    @RequestMapping(value = "/helper", method = RequestMethod.GET)
    public ModelAndView getList() {
        ModelAndView mv = null;
        try {
            HelperService service = new HelperService();
            List<Helper> helperList = service.read();
            mv = new ModelAndView("list");
            mv.addObject("helperList", helperList);
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }

    @RequestMapping(value = "/helper/{id}/delete", method = RequestMethod.GET)
    public ModelAndView delete(@PathVariable Long id) {
        ModelAndView mv = null;
        try {
            HelperService service = new HelperService();
            service.delete(id);
            mv = new ModelAndView("redirect:/helper");
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }
    
    @RequestMapping(value = "/helper/{id}/update", method = RequestMethod.GET)
    public ModelAndView getFormForUpdate(@PathVariable Long id) {
        ModelAndView mv = null;
        try {
            HelperService service = new HelperService();
            Helper helper = service.readById(id);
            mv = new ModelAndView("form");
            mv.addObject("helper", helper);
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }
    
    @RequestMapping(value = "/helper/{id}/update", method = RequestMethod.POST)
    public ModelAndView update(@PathVariable Long id, Helper helper) {
        ModelAndView mv = null;
        try {
            HelperService service = new HelperService();
            service.update(helper);
            mv = new ModelAndView ("redirect:/helper");
            mv.addObject("helper", helper);
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }
    
    
    

}
